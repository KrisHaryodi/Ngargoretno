<?php  
	$base_url = "http://localhost/MCM/";
	$admin_url = "http://localhost/MCM/admin/";
	$member_url = "http://localhost/MCM/member/"
?>
