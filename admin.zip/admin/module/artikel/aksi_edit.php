<?php 
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
    echo "<script> alert('Untuk Mengakses Member Anda Harus Login'); window.location = '../../index.php';</script>";
} else {
	include "../../../lib/config.php";
	include "../../../lib/koneksi.php";

	$id_member = $_POST['id_member'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$namausaha = $_POST['nama_usaha'];
	$nama = $_POST['nama_pemilik'];
	$noktp = $_POST['no_ktp'];
	$kodepos = $_POST['kode_pos'];
	$alamat = $_POST['alamat'];
	$email = $_POST['email'];
	$no_hp = $_POST['no_hp'];

	$namafile = $_FILES['foto']['name'];
	$lokasifile = $_FILES['foto']['tmp_name'];

  	$uploaddir = "../../img/";
  	$uploadfile = $uploaddir.$namafile;
	
	if(!empty($lokasifile)){
		$queryEdit = mysqli_query($konek,"UPDATE tbl_member SET username = '$username', password = '$password', nama_usaha = '$namausaha', nama_pemilik = '$nama', no_ktp = '$noktp', kode_pos = '$kodepos', alamat = '$alamat', email = '$email', no_hp = '$no_hp', foto = '$namafile' WHERE id_member='$id_member'");
		if($queryEdit){
		move_uploaded_file($lokasifile, $uploadfile);
		echo "<script>alert('Data Berhasil Diedit'); window.location = '$admin_url'+'adminweb.php?module=member';</script>";
		}else{
		echo "<script>alert('Data Gagal Diedit'); window.location = '$admin_url'+'adminweb.php?module=member';</script>";
		}
	}else{
		$queryEdit = mysqli_query($konek,"UPDATE tbl_member SET username = '$username', password = '$password', nama_usaha = '$namausaha', nama_pemilik = '$nama', no_ktp = '$noktp', kode_pos = '$kodepos', alamat = '$alamat', email = '$email', no_hp = '$no_hp' WHERE id_member='$id_member'");
		echo "<script>alert('Data Berhasil Diedit'); window.location = '$admin_url'+'adminweb.php?module=member';</script>";

	}
}
 ?>