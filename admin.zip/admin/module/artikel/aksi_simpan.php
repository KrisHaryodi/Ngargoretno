
 <?php 
session_start();

if(empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<script> alert('Akses ditolak, Anda harus login'); window.location = '../../index.php';</script>";
} else {
  include "../../../lib/config.php";
  include "../../../lib/koneksi.php";

  //ambil data gambar
  $namafile = $_FILES['foto']['name'];
  $lokasifile = $_FILES['foto']['tmp_name'];
  //selain gambar

	$username = $_POST['username'];
	$password = $_POST['password'];
  $namausaha = $_POST['nama_usaha'];
	$nama = $_POST['nama_pemilik'];
  $noktp = $_POST['no_ktp'];
  $kodepos = $_POST['kode_pos'];
	$alamat = $_POST['alamat'];
	$email = $_POST['email'];
	$no_hp = $_POST['no_hp'];
  $level = $_POST['level'];

  //set folder penyimpanan gambar
  $uploaddir = "../../img/";
  $uploadfile = $uploaddir.$namafile;

  if(move_uploaded_file($lokasifile, $uploadfile)){
  $querySimpan = mysqli_query($konek, "INSERT INTO tbl_member (username, password, nama_usaha, nama_pemilik, no_ktp, kode_pos, alamat, email, no_hp, foto, level) VALUES ('$username', '$password', '$namausaha', '$nama', '$noktp', '$kodepos', '$alamat', '$email', '$no_hp', '$namafile', '$level')");
     echo "<script> alert ('Data Berhasil Ditambahkan'); window.location = '$admin_url'+'adminweb.php?module=member'; </script>";
  }else{
    echo "<script> alert ('Data Gagal Ditambahkan'); window.location = '$admin_url'+'adminweb.php?module=member';</script>";
  }
}
?>