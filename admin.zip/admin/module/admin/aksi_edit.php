<?php 
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
	echo "<center>Untuk Mengakses User Anda Harus Login <br>";
	echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {
	include "../../../lib/config.php";
	include "../../../lib/koneksi.php";

	$id_admin = $_POST['id_admin'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$nama = $_POST['nama'];
	$email = $_POST['email'];

	$namafile = $_FILES['foto']['name'];
	$lokasifile = $_FILES['foto']['tmp_name'];

  	$uploaddir = "../../img/";
  	$uploadfile = $uploaddir.$namafile;

	$queryEdit = mysqli_query($konek, "UPDATE tbl_admin SET username='$username', password = '$password', nama = '$nama', email = '$email', foto = '$namafile' WHERE id_admin='$id_admin'");
	if ($queryEdit) {
		echo "<script> alert('Data Berhasil Diedit'); window.location = '$admin_url'+'adminweb.php?module=admin';</script>";
	} else {
		echo "<script> alert('Data Gagal Diedit'); window.location = '$admin_url'+'adminweb.php?module=edit_admin&id_admin='+'$id_admin';</script>";
	}
}
 ?>