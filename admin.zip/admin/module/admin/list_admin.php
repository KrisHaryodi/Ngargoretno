<section class="content-header">
      <h1>List Admin
        <small>Control Panel</small>
      </h1>
  <ol class="breadcrumb">      
    <li>
      <a href="#">
        <i class="fa fa-dashboard"></i> Home
      </a>
    </li>
    <li class="active">List Admin</li>
  </ol>
        
      
    </section>
<!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <a href="adminweb.php?module=tambah_admin" class="btn btn-success"><i class='fa fa-plus'> Tambah Admin</i></a>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>  
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Foto</th>
                    <th style="width: 110px">Aksi</th>
                </tr>
                </thead>
                <tbody>
                        <?php
                        include "../lib/config.php";
                        include "../lib/koneksi.php";
                        $kueriAdmin = mysqli_query($konek,"select * from tbl_admin");
                        $n = 1;
                        while ($adm = mysqli_fetch_array($kueriAdmin)) {
                        ?>
                    <tr>
                        <td><?= $n ?></td>
                        <td><?php echo $adm['username'];?></td>
                        <td><?php echo $adm['nama'];?></td>
                        <td><?php echo $adm['email'];?></td>
                        <td><img src="img/<?php echo $adm['foto'];?>" height="100" width="150"></td>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo $admin_url; ?>adminweb.php?module=edit_admin&id_admin=<?php echo $adm['id_admin'];?>" class="btn btn-warning"><i class='fa fa-pencil'></i></a>
                                <a href="<?php echo $admin_url; ?>module/admin/aksi_hapus.php?id_admin=<?php echo $adm['id_admin'];?>" onClick="return confirm('Anda yakin ingin menghapus data ini?')" class="btn btn-danger"><i class='fa fa-power-off'></i></a>
                            </div>
                        </td>
                    </tr>             
                </tbody>
                <?php $n++; 
                }   
                ?>
                </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
