<?php 
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
	echo "<script> alert('Untuk Mengakses Admin Forum Anda Harus Login'); window.location = '../../../index.php';</script>";
} else {
	include "../../../../lib/config.php";
	include "../../../../lib/koneksi.php";

	$id_admforum = $_POST['id_admforum'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$nama = $_POST['nama'];

	$namafile = $_FILES['foto']['name'];
	$lokasifile = $_FILES['foto']['tmp_name'];

  	$uploaddir = "../../../img/";
  	$uploadfile = $uploaddir.$namafile;


  	if(!empty($lokasifile)){
		$queryEdit = mysqli_query($konek, "UPDATE tbl_admforum SET username='$username', password = '$password', nama = '$nama', foto = '$namafile' WHERE id_admforum='$id_admforum'");
		if($queryEdit){
		move_uploaded_file($lokasifile, $uploadfile);
		echo "<script>alert('Data Berhasil Diedit'); window.location = '$admin_url'+'adminweb.php?module=admforum';</script>";
		}else{
		echo "<script>alert('Data Gagal Diedit'); window.location = '$admin_url'+'adminweb.php?module=admforum';</script>";
		}
	}else{
		$queryEdit = mysqli_query($konek, "UPDATE tbl_admforum SET username='$username', password = '$password', nama = '$nama' WHERE id_admforum='$id_admforum'");
		echo "<script>alert('Data Berhasil Diedit'); window.location = '$admin_url'+'adminweb.php?module=admforum';</script>";

	}
}
?>