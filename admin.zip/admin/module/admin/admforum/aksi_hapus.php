<?php 
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
	echo "<script> alert('Untuk Mengakses Admin Forum Anda Harus Login'); window.location = '../../../index.php';</script>";

} else {
	include "../../../../lib/config.php";
	include "../../../../lib/koneksi.php";

	$id_admforum = $_GET['id_admforum'];
	$queryHapus = mysqli_query($konek, "DELETE FROM tbl_admforum WHERE id_admforum='$id_admforum'");

	if ($queryHapus) {
		echo "<script> alert('Data Berhasil Dihapus'); window.location = '$admin_url'+'adminweb.php?module=admforum';</script>";
	} else {
		echo "<script> alert('Data Gagal Dihapus'); window.location = '$admin_url'+'adminweb.php?module=admforum';</script>";
	}
}
 ?>