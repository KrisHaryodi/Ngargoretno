
 <?php 
session_start();

if(empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<center>Akses ditolak, Anda harus login<br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {
  include "../../../lib/config.php";
  include "../../../lib/koneksi.php";

  //ambil data gambar
  $namafile = $_FILES['foto']['name'];
  $lokasifile = $_FILES['foto']['tmp_name'];
  //selain gambar
	$username = $_POST['username'];
	$password = $_POST['password'];
	$nama = $_POST['nama'];
	$email = $_POST['email'];
  //set folder penyimpanan gambar
  $uploaddir = "../../img/";
  $uploadfile = $uploaddir.$namafile;

  if(move_uploaded_file($lokasifile, $uploadfile)){
  $querySimpan = mysqli_query($konek, "INSERT INTO tbl_admin (username, password, nama, email,foto) VALUES ('$username','$password','$nama','$email','$namafile')");
     echo "<script> alert ('Data Berhasil Ditambahkan'); window.location = '$admin_url'+'adminweb.php?module=admin'; </script>";
  }else{
    echo "<script> alert ('Data Gagal Ditambahkan'); window.location = '$admin_url'+'adminweb.php?module=admin';</script>";
  }
}
?>