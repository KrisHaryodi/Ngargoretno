<?php 
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
	echo "<center>Untuk Mengakses User Anda Harus Login <br>";
	echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {
	include "../../../lib/config.php";
	include "../../../lib/koneksi.php";

	$id_admin = $_GET['id_admin'];
	$queryHapus = mysqli_query($konek, "DELETE FROM tbl_admin WHERE id_admin='$id_admin'");

	if ($queryHapus) {
		echo "<script> alert('Data Berhasil Dihapus'); window.location = '$admin_url'+'adminweb.php?module=admin';</script>";
	} else {
		echo "<script> alert('Data Gagal Dihapus'); window.location = '$admin_url'+'adminweb.php?module=admin';</script>";
	}
}
 ?>