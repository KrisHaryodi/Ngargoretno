<?php 
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
    echo "<script> alert('Untuk Mengakses Home Anda Harus Login'); window.location = '../../index.php';</script>";
} else {
	include "../../../lib/config.php";
	include "../../../lib/koneksi.php";

	$judul = $_POST['judul'];
    $isi = $_POST['isi'];
	
	$querySimpan = mysqli_query($konek, "INSERT INTO tbl_profile (profile_judul, profile_isi) VALUES ('$judul', '$isi')");
	if ($querySimpan) {
		echo "<script> alert('Data Berhasil Ditambahkan'); window.location = '$admin_url' +'adminweb.php?module=home';</script>";
	} else {
		echo "<script> alert('Data Gagal Ditambahkan'); window.location = '$admin_url' +'adminweb.php?module=tambah_home';</script>";
	}
}
 ?>